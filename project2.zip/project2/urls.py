
from django.contrib import admin
from django.urls import path
from blogeconomy import views
from django.conf.urls import url,include
urlpatterns = [

    url(r'admin/', admin.site.urls),
    url(r'^$',include('mainApp.urls')),
    url(r'blogeconomy/',include('blogeconomy.urls'))
]
